from generator import generate_password
from ui import get_user_input, show_password

def main():
    print("Password Generator Project ")
    length, letters, digits, symbols = get_user_input()
    password = generate_password(length, letters, digits, symbols)
    show_password(password)

if __name__ == "__main__":
    main()
