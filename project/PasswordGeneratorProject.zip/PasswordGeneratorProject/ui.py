def get_user_input():
    length = int(input("Enter password length: "))
    letters = input("Include letters? (y/n): ").lower() == 'y'
    digits = input("Include digits? (y/n): ").lower() == 'y'
    symbols = input("Include symbols? (y/n): ").lower() == 'y'
    return length, letters, digits, symbols

def show_password(password):
    print("\nYour secure password is:", password)
